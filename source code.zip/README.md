# GTA-Real-Estate-Price-Prediction
A tool for predicting the price of real estate in the Greater Toronto Area based on machine learning skills.
